from .cnn import CNN
from .resnet import RestNet

__all__ = ['CNN', 'RestNet'] 